package org.example;

class ComparacionNumerosTest {

    @org.junit.jupiter.api.BeforeEach
    void setUp() {
    }

    @org.junit.jupiter.api.AfterEach
    void tearDown() {
    }

    @org.junit.jupiter.api.Test
    void main() {
    }

    @org.junit.jupiter.api.Test
    void mayorDeDos() {
    }

    @org.junit.jupiter.api.Test
    void clasificarNumeros() {
    }
}